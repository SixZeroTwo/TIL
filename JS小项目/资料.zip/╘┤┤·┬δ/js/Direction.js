const Direction = {
  // 使用up 表示方向的上，其他同理
  up : 0,
  right: 1,
  down : 2,
  left : 3
}
export default Direction;