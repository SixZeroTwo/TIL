const Direction = {
  up: 0,
  right: 1,
  down: 2,
  left: 3
}
export default Direction;