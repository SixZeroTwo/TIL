const BlockType = {
  grass: 0,
  wall: 1,
  water: 2
}
export default BlockType;