// 定义一个点对象，描述一个点坐标
export default class Point {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
  }
}