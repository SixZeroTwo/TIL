const Status = {
  alive: 0,
  die: 1,
  expload: 2
}
export default Status;